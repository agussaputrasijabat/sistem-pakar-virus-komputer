<?php
$db_host = 'localhost';
$db_user = 'jabatsof_user';
$db_password = 'adxscmpri123';
$db_name = 'jabatsof_sp_kom';

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);
