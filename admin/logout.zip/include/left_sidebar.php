<aside class="left-sidebar" data-sidebarbg="skin5">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav" class="p-t-30">
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="./" aria-expanded="false">
                        <i class="mdi mdi-view-dashboard"></i><span class="hide-menu">Home</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="?module=virus" aria-expanded="false">
                        <i class="mdi mdi-chart-bar"></i><span class="hide-menu">Virus Komputer</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="?module=gejala" aria-expanded="false">
                        <i class="mdi mdi-chart-bubble"></i><span class="hide-menu">Gejala</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="?module=aturan" aria-expanded="false">
                        <i class="mdi mdi-border-inside"></i><span class="hide-menu">Aturan</span>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside>
