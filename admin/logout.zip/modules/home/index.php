<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h4 class="page-title">Home</h4>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="alert alert-info" role="alert">
        <h4 class="alert-heading">Selamat Datang!</h4>
        <p>Ini adalah halaman untuk Admin agar bisa menambahkan data-data virus dan gejala serta menerapkan aturan-aturannya. </p>
    </div>
</div>